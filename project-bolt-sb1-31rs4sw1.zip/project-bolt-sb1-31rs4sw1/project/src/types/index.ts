// Type definition for a lesson within a course
export interface Lesson {
  id: number;
  title: string;
  duration: string;
  completed: boolean;
}

// Type definition for a course
export interface Course {
  id: number;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  level: string;
  image: string;
  lessons: Lesson[];
}
