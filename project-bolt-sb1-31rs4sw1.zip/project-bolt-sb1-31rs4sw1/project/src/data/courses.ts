import { Course } from '../types';

// Course data stored in a JavaScript array
export const coursesData: Course[] = [
  {
    id: 1,
    title: 'Web Development Fundamentals',
    description: 'Learn the basics of HTML, CSS, and JavaScript to build modern websites from scratch.',
    instructor: 'Sarah Johnson',
    duration: '6 hours',
    level: 'Beginner',
    image: '🌐',
    lessons: [
      { id: 1, title: 'Introduction to HTML', duration: '45 min', completed: false },
      { id: 2, title: 'CSS Styling Basics', duration: '60 min', completed: false },
      { id: 3, title: 'JavaScript Fundamentals', duration: '90 min', completed: false },
      { id: 4, title: 'Building Your First Website', duration: '120 min', completed: false },
      { id: 5, title: 'Responsive Design Principles', duration: '75 min', completed: false }
    ]
  },
  {
    id: 2,
    title: 'Advanced React Development',
    description: 'Master React hooks, state management, and build scalable applications with modern best practices.',
    instructor: 'Michael Chen',
    duration: '8 hours',
    level: 'Advanced',
    image: '⚛️',
    lessons: [
      { id: 6, title: 'React Hooks Deep Dive', duration: '90 min', completed: false },
      { id: 7, title: 'State Management with Context', duration: '75 min', completed: false },
      { id: 8, title: 'Performance Optimization', duration: '60 min', completed: false },
      { id: 9, title: 'Advanced Patterns', duration: '105 min', completed: false },
      { id: 10, title: 'Testing React Applications', duration: '90 min', completed: false }
    ]
  },
  {
    id: 3,
    title: 'UI/UX Design Principles',
    description: 'Discover the art and science of creating beautiful, user-friendly interfaces that delight users.',
    instructor: 'Emma Rodriguez',
    duration: '5 hours',
    level: 'Intermediate',
    image: '🎨',
    lessons: [
      { id: 11, title: 'Design Thinking Fundamentals', duration: '50 min', completed: false },
      { id: 12, title: 'Color Theory and Typography', duration: '65 min', completed: false },
      { id: 13, title: 'User Research Methods', duration: '70 min', completed: false },
      { id: 14, title: 'Wireframing and Prototyping', duration: '80 min', completed: false },
      { id: 15, title: 'Usability Testing', duration: '55 min', completed: false }
    ]
  }
];
