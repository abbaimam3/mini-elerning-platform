import { ArrowLeft, Clock, BarChart, Award } from 'lucide-react';
import { Course } from '../types';
import LessonItem from './LessonItem';

interface CourseDetailProps {
  course: Course;
  onBack: () => void;
  onMarkLessonCompleted: (lessonId: number) => void;
}

// Course detail page component showing lessons and progress
function CourseDetail({ course, onBack, onMarkLessonCompleted }: CourseDetailProps) {
  // Calculate overall progress
  const completedLessons = course.lessons.filter(l => l.completed).length;
  const totalLessons = course.lessons.length;
  const progressPercentage = (completedLessons / totalLessons) * 100;
  const isCompleted = completedLessons === totalLessons;

  return (
    <div className="min-h-screen">
      {/* Header Section with Back Button */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="container mx-auto px-4 py-8 max-w-5xl">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-white hover:text-blue-100 transition-colors mb-6 group"
          >
            <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
            <span className="font-medium">Back to Courses</span>
          </button>

          <div className="flex items-start gap-8">
            {/* Course Icon */}
            <div className="text-8xl bg-white/10 rounded-2xl p-8 backdrop-blur-sm">
              {course.image}
            </div>

            {/* Course Info */}
            <div className="flex-1">
              <span className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3 bg-white/20">
                {course.level}
              </span>
              <h1 className="text-4xl font-bold mb-3">{course.title}</h1>
              <p className="text-blue-100 text-lg mb-4">{course.description}</p>
              <p className="text-blue-100 mb-4">
                Instructor: <span className="font-semibold text-white">{course.instructor}</span>
              </p>

              {/* Meta Info */}
              <div className="flex items-center gap-6 text-blue-100">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center gap-2">
                  <BarChart className="w-5 h-5" />
                  <span>{totalLessons} lessons</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="container mx-auto px-4 py-12 max-w-5xl">
        {/* Progress Section */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-slate-800">Your Progress</h2>
            {isCompleted && (
              <div className="flex items-center gap-2 text-green-600">
                <Award className="w-6 h-6" />
                <span className="font-semibold">Course Completed!</span>
              </div>
            )}
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between text-sm text-slate-600 mb-2">
              <span>{completedLessons} of {totalLessons} lessons completed</span>
              <span className="font-semibold">{Math.round(progressPercentage)}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-4 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  isCompleted ? 'bg-green-500' : 'bg-blue-600'
                }`}
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>

          <p className="text-slate-600">
            {isCompleted
              ? 'Congratulations! You have completed all lessons in this course.'
              : 'Keep going! Complete all lessons to finish the course.'}
          </p>
        </div>

        {/* Lessons List */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-slate-800 mb-6">Course Lessons</h2>
          <div className="space-y-3">
            {course.lessons.map((lesson, index) => (
              <LessonItem
                key={lesson.id}
                lesson={lesson}
                index={index}
                onToggleComplete={() => onMarkLessonCompleted(lesson.id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default CourseDetail;
