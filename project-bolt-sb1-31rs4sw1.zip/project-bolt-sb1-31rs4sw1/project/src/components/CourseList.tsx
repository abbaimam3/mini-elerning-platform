import { BookOpen } from 'lucide-react';
import { Course } from '../types';
import CourseCard from './CourseCard';

interface CourseListProps {
  courses: Course[];
  onSelectCourse: (course: Course) => void;
}

// Home page component that displays all available courses
function CourseList({ courses, onSelectCourse }: CourseListProps) {
  return (
    <div className="container mx-auto px-4 py-12 max-w-7xl">
      {/* Header Section */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center mb-4">
          <BookOpen className="w-12 h-12 text-blue-600" />
        </div>
        <h1 className="text-5xl font-bold text-slate-800 mb-4">
          Learn at Your Own Pace
        </h1>
        <p className="text-xl text-slate-600 max-w-2xl mx-auto">
          Explore our carefully curated courses designed to help you master new skills and advance your career.
        </p>
      </div>

      {/* Course Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map(course => (
          <CourseCard
            key={course.id}
            course={course}
            onSelect={() => onSelectCourse(course)}
          />
        ))}
      </div>
    </div>
  );
}

export default CourseList;
