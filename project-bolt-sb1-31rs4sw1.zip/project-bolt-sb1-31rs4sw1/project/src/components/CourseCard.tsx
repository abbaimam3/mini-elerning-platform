import { Clock, BarChart } from 'lucide-react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onSelect: () => void;
}

// Individual course card component with hover effects
function CourseCard({ course, onSelect }: CourseCardProps) {
  // Calculate progress percentage based on completed lessons
  const completedLessons = course.lessons.filter(l => l.completed).length;
  const totalLessons = course.lessons.length;
  const progressPercentage = (completedLessons / totalLessons) * 100;

  // Determine level badge color
  const getLevelColor = (level: string) => {
    switch (level.toLowerCase()) {
      case 'beginner':
        return 'bg-green-100 text-green-700';
      case 'intermediate':
        return 'bg-yellow-100 text-yellow-700';
      case 'advanced':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div
      onClick={onSelect}
      className="bg-white rounded-xl shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2 overflow-hidden group"
    >
      {/* Course Icon/Image */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 h-48 flex items-center justify-center text-8xl group-hover:scale-110 transition-transform duration-300">
        {course.image}
      </div>

      {/* Course Content */}
      <div className="p-6">
        {/* Level Badge */}
        <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3 ${getLevelColor(course.level)}`}>
          {course.level}
        </span>

        {/* Course Title */}
        <h3 className="text-2xl font-bold text-slate-800 mb-2 group-hover:text-blue-600 transition-colors">
          {course.title}
        </h3>

        {/* Course Description */}
        <p className="text-slate-600 mb-4 line-clamp-2">
          {course.description}
        </p>

        {/* Instructor */}
        <p className="text-sm text-slate-500 mb-4">
          by <span className="font-semibold text-slate-700">{course.instructor}</span>
        </p>

        {/* Meta Information */}
        <div className="flex items-center justify-between text-sm text-slate-600 mb-4">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{course.duration}</span>
          </div>
          <div className="flex items-center gap-1">
            <BarChart className="w-4 h-4" />
            <span>{totalLessons} lessons</span>
          </div>
        </div>

        {/* Progress Bar */}
        {progressPercentage > 0 && (
          <div className="mb-4">
            <div className="flex justify-between text-xs text-slate-600 mb-1">
              <span>Progress</span>
              <span>{Math.round(progressPercentage)}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
              <div
                className="bg-blue-600 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>
        )}

        {/* Call to Action Button */}
        <button className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200 shadow-md hover:shadow-lg">
          {progressPercentage > 0 ? 'Continue Learning' : 'Start Course'}
        </button>
      </div>
    </div>
  );
}

export default CourseCard;
