import { CheckCircle, Circle, Clock } from 'lucide-react';
import { Lesson } from '../types';

interface LessonItemProps {
  lesson: Lesson;
  index: number;
  onToggleComplete: () => void;
}

// Individual lesson item component with completion toggle
function LessonItem({ lesson, index, onToggleComplete }: LessonItemProps) {
  return (
    <div
      className={`flex items-center justify-between p-5 rounded-lg border-2 transition-all duration-200 ${
        lesson.completed
          ? 'bg-green-50 border-green-200'
          : 'bg-slate-50 border-slate-200 hover:border-blue-300 hover:shadow-md'
      }`}
    >
      {/* Lesson Info */}
      <div className="flex items-center gap-4 flex-1">
        {/* Lesson Number */}
        <div
          className={`flex items-center justify-center w-10 h-10 rounded-full font-bold ${
            lesson.completed
              ? 'bg-green-200 text-green-700'
              : 'bg-slate-200 text-slate-600'
          }`}
        >
          {index + 1}
        </div>

        {/* Lesson Details */}
        <div className="flex-1">
          <h3
            className={`font-semibold text-lg ${
              lesson.completed ? 'text-green-800' : 'text-slate-800'
            }`}
          >
            {lesson.title}
          </h3>
          <div className="flex items-center gap-1 text-slate-600 text-sm mt-1">
            <Clock className="w-4 h-4" />
            <span>{lesson.duration}</span>
          </div>
        </div>

        {/* Completion Status Icon */}
        <div>
          {lesson.completed ? (
            <CheckCircle className="w-8 h-8 text-green-600" />
          ) : (
            <Circle className="w-8 h-8 text-slate-300" />
          )}
        </div>
      </div>

      {/* Mark as Completed Button */}
      <button
        onClick={onToggleComplete}
        className={`ml-4 px-6 py-2 rounded-lg font-semibold transition-all duration-200 shadow-md hover:shadow-lg ${
          lesson.completed
            ? 'bg-slate-600 text-white hover:bg-slate-700'
            : 'bg-blue-600 text-white hover:bg-blue-700'
        }`}
      >
        {lesson.completed ? 'Mark Incomplete' : 'Mark as Completed'}
      </button>
    </div>
  );
}

export default LessonItem;
