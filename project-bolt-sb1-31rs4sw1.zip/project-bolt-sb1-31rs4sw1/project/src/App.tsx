import { useState } from 'react';
import CourseList from './components/CourseList';
import CourseDetail from './components/CourseDetail';
import { Course } from './types';
import { coursesData } from './data/courses';

function App() {
  // State to track which course is currently selected (null = show home page)
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);

  // State to manage all courses and their completion status
  const [courses, setCourses] = useState<Course[]>(coursesData);

  // Handler to select a course and navigate to detail view
  const handleSelectCourse = (course: Course) => {
    setSelectedCourse(course);
  };

  // Handler to go back to home page
  const handleBackToHome = () => {
    setSelectedCourse(null);
  };

  // Handler to mark a lesson as completed
  const handleMarkLessonCompleted = (lessonId: number) => {
    if (!selectedCourse) return;

    // Update the courses array with the new completion status
    const updatedCourses = courses.map(course => {
      if (course.id === selectedCourse.id) {
        const updatedLessons = course.lessons.map(lesson =>
          lesson.id === lessonId ? { ...lesson, completed: !lesson.completed } : lesson
        );
        return { ...course, lessons: updatedLessons };
      }
      return course;
    });

    setCourses(updatedCourses);

    // Update the selected course to reflect changes immediately
    const updatedSelectedCourse = updatedCourses.find(c => c.id === selectedCourse.id);
    if (updatedSelectedCourse) {
      setSelectedCourse(updatedSelectedCourse);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Render either the course list (home) or course detail view */}
      {selectedCourse ? (
        <CourseDetail
          course={selectedCourse}
          onBack={handleBackToHome}
          onMarkLessonCompleted={handleMarkLessonCompleted}
        />
      ) : (
        <CourseList courses={courses} onSelectCourse={handleSelectCourse} />
      )}
    </div>
  );
}

export default App;
